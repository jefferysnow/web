function saveSelectIndex(){
   var typeId=document.getElementById("typeId");
   var typeIdText=typeId.options[typeId.selectedIndex].value;
   var osId=document.getElementById("osId");
   var osIdText=osId.options[osId.selectedIndex].value;
   //���ö��cookie 
   document.cookie="typeIdText="+typeIdText;
   document.cookie="osIdText="+osIdText;
}

function selectIndex(){
   //�ǵó�ʼ������������undefined
   var typeIdText=0;
   var osIdText=0;
   //��ȡ���cookie
   var coosStr=document.cookie;//ע��˴��ָ����Ƿֺżӿո�
   var coos=coosStr.split("; ");
   for(var i=0;i<coos.length;i++){
      var coo=coos[i].split("=");
      //alert(coo[0]+":"+coo[1]);
      if("typeIdText"==coo[0]){
         typeIdText=coo[1];
      }if("osIdText"==coo[0]){
         osIdText=coo[1];
      }
   }
  
   var typeId=document.getElementById("typeId");
   if(typeIdText==0){
      typeId.selectedIndex=0;
   }else{
      var length=typeId.options.length;
      for(var i=0;i<length;i++){
         if(typeId.options[i].value==typeIdText){
            typeId.selectedIndex=i;
            break;
         }
      }
   }
   
   var osId=document.getElementById("osId");
   if(osIdText==0){
      osId.selectedIndex=0;
   }else{
      var length=typeId.options.length;
      for(var i=0;i<length;i++){
         if(osId.options[i].value==osIdText){
            osId.selectedIndex=i;
            break;
         }
      }
   }
   
}