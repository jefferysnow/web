<?php
    require_once('../main/domain.php');
    require_once('../config/conn.php');
//�������ӹ�����
    if (isset($_REQUEST['addomain'])) {
        die ('<p style="color:red">��δ����...</p>');
    }
//��������-->�����̳�      >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $ip   = trim($_REQUEST['ip']) or die('<p style="color:red;text-indent: 10px">������IP...');
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){
        die ('<p style="color:red;text-indent: 10px">IP�������');
    }
    $file = '/web/web_log/data/rec_ip.res' ;
    $text = file_get_contents($file);
    $array_text = explode("\n",$text);
    $wc = substr_count($text,$ip)+2;


//��ӡ��Ϣ
    echo '<table  width="40%" border="2" cellspacing="1" cellpadding="2" bordercolor="#009900" style="font-size:10px">';
    echo '<tr>
            <td align="middle" width="10%">IP</td>
            <td colspan="2" align="middle" width="30%">����</td>
          </tr>
          <tr>
            <td rowspan="'.$wc.'" align="middle">'.$ip.'</td>
          </tr>';
          

    

    //ѭ���������;
    foreach ($array_text as $array_line){
        if ( strstr($array_line,$ip)){
            $domain=str_replace($ip.'|','',$array_line);
            echo '<tr><td style="text-align:left;border-right-width: 2px;border-bottom-width: 2px;">'.$domain.'</td></tr>' ;
        }
        if ( strstr($array_line,'time')){
            $time = str_replace('time|','',$array_line);
        }
    }
    if (!substr_count($text,$ip)){
        echo '<tr><td style="text-align:center;border-right-width: 2px;border-bottom-width: 2px;">null</td></tr>' ;
    }
//echo '<tr><td align="left">'.$domain.'</td></tr>';
    echo '</table><p>˵����<font size="2">Ĭ�ϲ���ʾwww������������IP��ͬ����ʾ</p>
        <p style="margin-left:310px"><font size="1">���ݲɼ�ʱ�䣺'.$time.'</font></p>';

?>