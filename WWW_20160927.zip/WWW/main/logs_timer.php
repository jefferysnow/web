<?php
  require('../include/logs_header.php');
?>

<!--����header.phpδ��ɵĲ˵�-->
    <li><A href="./../main/main_page.php">��ҳ</A></li>
    <li><A href="./../main/task.php">�������</A></li>
    <li><A href="./../main/maintain.php">�ճ���ά</A></li>
    <li><A href="./../main/domain.php">��������</A></li>
    <li><A href="./../main/listen.php">��ع���</A></li>
    <li><A class="hover" href="./../main/logs.php">��־��ѯ</A></li>
    <li><A href="./../main/roster.php">�Ű�ı�</A></li>
    <li><A href="./../main/help.php">ʹ��˵��</A></li>
    <div id="lanPos"></div>
  </ul>
  </td><!-- �˵��������td -->
  <td class="content" ><br/>
    <form >
      <fieldset>
        <div class="DivSelect">
          <select name="valueA" id="valueA" class="SelectList"  >
          </select>
            <!--ѭ������24Сʱʱ��ѡ��-->
            <script type="text/javascript"> 
              for (var i=0;i<24;i++) {
                if (i<10) {
                  i="0"+i
                }
                for (var j=0;j<60;j=parseInt(j, 10)+10) {
                  if (j<10) {
                    j="0"+j
                  }
                  var time=i+":"+j;
                  var obj = document.getElementById("valueA");
                  obj.add(new Option(time,time));
                }
              }
            </script>
        </div> 
      </fieldset>
    </form>
    
  <div style="line-height:12px;width: 99%;height: 93%;text-indent: 0px;background-color:#ffffff;"  color:#000000 ;>

<!--label id="closeOnSelect"><input type="checkbox" /> Close on selection</label-->



