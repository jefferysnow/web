<html>
<head>
<title>webjx.com</title>
</head>


<body text="#000000">
<center>
<table width="500" border="3">
<tr>
<td width="140" height="400" valign="top">
<p align="center">
<a href='index.php'>home</a><br />
<a href='index.php?p=Page1'>page 1</a><br />
<a href='index.php?p=Page2'>page 2</a><br />
</p></td>
<td width="360" height="400" valign="top">
<p>
<?
function index()
{
echo "<p align=center>Welcome to this tutorial<br />Here you can find funny
tricks</p><br /><br /><br /><br /><br /><br />"; }
$choice=$_GET['p'];

switch($choice)
{
case "Page1":

echo "<p align=center>Page1 text, img and so on here</p>";
break;

case "Page2":

echo "<p align=center>Page2 text, img and so on here</p>";
break;

default:
index();
}

?>

</p>
</td>
</tr>
</table> </center>
</body>
</html>