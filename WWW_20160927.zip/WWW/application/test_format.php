    <html>  
    <head>  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">  
    <title>�ޱ����ĵ�</title>  
    </head>  
      
    <body>  
        <form>  
            First Name:  
            <input type="text" id="txt1" onKeyUp="showHint(this.value)">    
        </form>  
        <p>  
            Suggestions:<span id="txtHint"></span>  
        </p>  
      
    </body>  
    <script src="jquery.min.js"></script>  
    <script type="text/javascript">  
        var xmlHttp;  
                        document.getElementById("txtHint").innerHTML="hh";  
      
        function showHint(str){  
            if(str.length==0){  
                document.getElementById("txtHint").innerHTML="";  
                return;  
            }  
            xmlHttp=GetXmlHttpObject();  
        if(xmlHttp==null){  
                alert("Brower does not support Http Request!");  
                return;  
            }  
              
            var url="chat.php";  
            url+="?q="+str;  
            url+="&sid="+Math.random();  
            xmlHttp.onreadystatechange=stateChanged;  
            xmlHttp.open("GET",url,true);  
            xmlHttp.send(null);  
        }  
          
            function stateChanged(){  
                if(xmlHttp.readyState==4 || xmlHttp.readyState=="complete"){  
                    document.getElementById("txtHint").innerHTML=xmlHttp.responseText;  
                }  
            }  
              
            function GetXmlHttpObject(){  
                var xmlhttp;  
                if (window.XMLHttpRequest)  
                  {// code for IE7+, Firefox, Chrome, Opera, Safari  
                  xmlhttp=new XMLHttpRequest();  
                  }  
                else  
                  {// code for IE6, IE5  
                  //�������д������ֱ����Firefox�����лᱨ������ʾ"ActiveXObject is not defined"��  
                  //������Ϊ����Ĵ���ֻ��������IE6��IE5��  
                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");           
                  }       
                return xmlHttp;  
            }         
    </script>  
    </html>  