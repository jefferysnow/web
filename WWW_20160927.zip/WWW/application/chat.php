    <html>  
    <head>  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">  
    <title>�ޱ����ĵ�</title>  
    </head>  
      
    <body>  
        <?php   
            $a[]="zhao";  
            $a[]="qian";  
            $a[]="sun";  
            $a[]="li";  
              
            $q=$_GET["q"];  
            if(strlen($q)>0){  
                $hint="";  
                for($i=0;$i<count($a);$i++){  
                    if(strtolower($q)==strtolower(substr($a[$i],0,strlen($q)))){  
                        if($hint==""){  
                            $hint=$a[$i];  
                        }  
                        else{  
                            $hint=$hint.",".$a[$i];  
                        }  
                    }  
                }  
            }  
              
            if($hint==""){  
                $response="No suggestion";  
            }  
            else  
            {  
                $response=$hint;  
            }  
            echo $response;  
        ?>  
    </body>  
    </html>  