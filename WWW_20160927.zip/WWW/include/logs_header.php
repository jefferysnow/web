<meta http-equiv="Content-Type" content="text/html charset=gb2312" xml:lang="en" lang="en">
<title>SA workpage</title>
<script src="../css/position.css" type="text/css"></script>
<link href="../css/basic.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script src="../js/jquery.min.js"></script>
<script src="../js/index.js"></script>
<script src="../js/clock.js" type="text/javascript"></script>
<script src="../js/sa_workpage_owns.js" type="text/javascript"></script>

<!--���ڿؼ�-->
<link rel="stylesheet" href="../css/datepicker.css" type="text/css" />
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../js/datepicker.js"></script>
<script type="text/javascript" src="../js/eye.js"></script>
<script type="text/javascript" src="../js/utils.js"></script>
<script type="text/javascript" src="../js/layout.js?ver=1.0.2"></script>

<!-- ʱ��̶ȹ����� 
    <script type="text/javascript" src="../js/jquery-ui-1.7.1.custom.min.js"></script>
    <script type="text/javascript" src="../js/selectToUISlider.jQuery.js"></script>
    <link rel="stylesheet" href="../css/redmond/jquery-ui-1.7.1.custom.css" type="text/css" />
    <link rel="Stylesheet" href="../css/ui.slider.extras.css" type="text/css" />
    <style type="text/css">
        /*body {font-size: 62.5%; font-family:"Segoe UI","Helvetica Neue",Helvetica,Arial,sans-serif; }
        fieldset { border:0; margin: 6em; height: 12em;}
        label {font-weight: normal; float: left; margin-right: .5em; font-size: 1.1em;}	
        select {margin-right: 1em; float: left;}*/
    </style>
    <script type="text/javascript">
        $(function(){
            $('select#valueA').selectToUISlider();
            //fix color 
        });
    </script>
-->


</head>
<!--body����-->
<body onload="startTime()" text="#000000" >

<!--��ҳ����-->
<table width="100%"  cellspacing="0" border="0" style="background-color: teal" >
    <tr >
      <td  width="35%">
        <img src="./../image/tcbc_teal.png" align=right >
      </td>
      <td width="35%" >
        <h1 >SA WorkPage</h1>
      </td>
      <td>
        <!-- ���Ͻǵ�ʱ��-->
        <span id="clock" class="clock"></span>
      </td>
    </tr>
</table>
<div> <a class="rollinfo">�����Ǵ��졢�澯�Ĺ�����Ϣ����</a></div>

<table width=100% style="height: 88%" cellpadding="5px" > <!-- ��������������-->
    <tr>
    <!-- ���˵���ʼtd -->
    <td class="menu"> 
    <ul >