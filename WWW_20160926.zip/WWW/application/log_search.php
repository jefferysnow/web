<?php
    require_once('../main/logs.php');
    require_once('../config/conn.php');
    echo '<tr ><td style="white-space:nowrap;color:grey">' ;
//��������-->�����̳�      >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $day       = trim($_REQUEST['day']);
    $plat      = trim($_REQUEST["plat"]);
    $project   = trim($_REQUEST["project"]);
    $begintime = isset($_REQUEST['begintime'])?trim($_REQUEST['begintime']):"00:00:00";
    $search    = trim($_REQUEST["search"]);
    $pagesize  = trim($_REQUEST["content"]);
    if ($begintime = 1){
        $begintime = '00:00:00';
    }
    //���浱ǰ������session
    $_SESSION['day']       = $day ;
    $_SESSION["plat"]      = $plat ;
    $_SESSION["project"]   = $project ;
    $_SESSION['begintime'] = $begintime ;
    $_SESSION["search"]    = $search ;
    $_SESSION["content"]   = $pagesize ;
    
    if (isset($_REQUEST['query_ontime'])) {
        die('<p style="color:red"><br/>ʵʱ��ʾ������.....�Ŷ����');
    }

    
    $search_day = str_replace('-','',$day); //ȥ��ʱ���е�-
    //��������-->�жϱ���
    if ($plat == "b79"&&$project == "web"){
        $tab_name = $plat ."_new_". $project ."_". $search_day ;
    }
    else {
        $tab_name = $plat ."_". $project ."_". $search_day ;
    }
    //��������-->ȥ��������Ŀո�
    trim($search); 
    trim($search_day);

//SQL����--�ϳ���SQL�Ӿ䣬ȷ��������Ŀ    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $query_rows_sql = "select count(id) from $tab_name ";
    if ($begintime != "00:00:00" && $search != "all"){
        $query_rows_sql .= " where time >= '$begintime' " . " and match(message) against('$search') " ;
    }
    elseif ($begintime != "00:00:00" && $search = "all") {
        $query_rows_sql .= " where time >= '$begintime' "   ;
    }
    elseif ($begintime = "00:00:00" && $search != "all") {
        $query_rows_sql .= " where match(message) against('$search') " ;
    }
    else {
        $query_rows_sql = "select max(id) from $tab_name ";
    }
    if (isset($_REQUEST['query_lost'])) {
        if (is_numeric($search) && strlen($search) > 6 ){
            $query_lost_sql = "select id,user from $tab_name where  match(message) against('$search') and user !='null' limit 1 ";
            $query_lost_date = @$link -> query($query_lost_sql);
            $array_lost_user = @$query_lost_date ->fetch_assoc();
            $lost_user = trim($array_lost_user['user']);
            $lost_id   = trim($array_lost_user['id']);
            $query_rows_sql = "select count(id) from $tab_name where  match(message) against('$search') and id >= $lost_id " ;   
        }
        else {
            die('<p style="color:red"><br/>��ˮ���������');
        }
    }
    $result_rows_date = @$link->query($query_rows_sql);
    $result_rows_array = @mysqli_fetch_array($result_rows_date) ;
    $result_rows = $result_rows_array[0];
//��ҳ����--������ҳ��    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $pages=intval($result_rows/$pagesize);
    if ($result_rows%$pagesize)
        $pages++;   //ҳ�벻������ʱ����ҳ����1
    if (!isset($_REQUEST['page'])){  
        $page=1;  //���δ����page����ǰĬ����ʾ��һҳ
    }
    else {
        $page = $_REQUEST['page'];
    }
    if (isset($_REQUEST['ys']) && $_REQUEST['ys'] > $pages ){
        $ys = $pages ;
        $page = $ys ;   //�ж��Ƿ�����תҳ��--�������ҳ�������ҳ������ѯҳ��=�����ҳ��
    }
    if (isset($_REQUEST['ys']) && $_REQUEST['ys'] <= $pages ){
        $ys = $_REQUEST['ys'] ;
        $page = $ys;    //�ж��Ƿ�����תҳ��--��ֵ����ѯҳ��
    }
    //�����¼ƫ����
    $bgein_line = $pagesize*($page-1);
    $end_line = $bgein_line + $pagesize;

//SQL����--�ϳɲ�ѯ����SQL    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $query_date_sql = "select id,ip,date,time,info,message from $tab_name ";
    $query_limit = "limit $pagesize ";
    if ($begintime != "00:00:00" && $search != "all"){
        $query_date_sql .= " where id >= $bgein_line and time >= $begintime' " . " and match(message) against('$search') " . $query_limit ;
    }
    elseif ($begintime != "00:00:00" && $search = "all") {
            $query_date_sql .= " where id >= $bgein_line and time >= '$begintime' " . $query_limit   ;
    }
    elseif ($begintime = "00:00:00" && $search != "all") {
        $query_date_sql .= " where id >= $bgein_line and match(message) against('$search') " . $query_limit   ;
    }
    else {
        $query_date_sql = $query_date_sql . "where id >= $bgein_line limit $pagesize " ;
    }
    if (isset($_REQUEST['query_lost'])) {
        $query_date_sql = "select id,ip,date,time,info,message from $tab_name where id >= $lost_id and user = '$lost_user'" ;
    }
//���ݴ���--��ѯ���ݡ�ȷ������Ŀ  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $result_search_date = @$link->query($query_date_sql);
    if (!$result_search_date) {
        die('<p style="color:red"><br/>��ѯ����Ϊ��<br/>������Ϣ����ѯ������������='.$day.',ƽ̨='.$plat.',����='.$project.
            ',�����ؼ���='.$search.',ÿҳ����='.$pagesize.',��ʼʱ��='.$begintime);
    }
    
    //ѭ�������ѯ���
    for ($i=1;$i<$pagesize;$i++){
        $show_search_date = @$result_search_date->fetch_assoc();
        $id      = trim($show_search_date['id']);
        $date    = trim($show_search_date['date']);
        $time    = trim($show_search_date['time']);
        $info    = trim($show_search_date['info']);
        $message = trim($show_search_date['message']);
        if (preg_match("/^at/",$message)){
            $date = '';
            $time = '';
            $info = '';
        }
        echo '<tr ><td style="white-space:nowrap;color:grey">' ;
        //echo htmlspecialchars(stripcslashes($id));
        //echo '</td><td style="white-space:nowrap;">| ' ;
        //echo htmlspecialchars(stripcslashes($date));
        //echo '</td><td style="white-space:nowrap;">' ;
        echo htmlspecialchars(stripcslashes($time));
        if ($info == 'ERROR'){
            echo '</td><td style="white-space:nowrap;text-align: right;font-size:0.5px;color:red">' ;
        }
        else {
            echo '</td><td style="white-space:nowrap;text-align: right;font-size:0.5px;color:grey">' ;
        }
        echo htmlspecialchars(stripcslashes($info)) .'&nbsp&nbsp';
        if (strstr($message,'confirm transfer') || strstr($message,'key_error')){
            echo '</td><td style="word-wrap:break-word;word-break:break-all;font-size:2px;color:red">' ;
        }
        else {
            echo '</td><td style="word-wrap:break-word;word-break:break-all;font-size:2px">' ;
        }
        if (strstr($message,$search)){
            $light_search = '<a style="background-color:#dade34">'.$search .'</a>';
            list($pre,$pro) = explode($search,$message);
            echo $pre.$light_search.$pro;
        }
        echo "$message";
        echo "</td></tr>";
    }
    $pre_send = 'day='.$day.'&plat='.$plat.'&project='.$project.'&search='.$search.'&content='.$pagesize.'&begintime="'.$begintime.'"';
    echo "</tbody></table></div><div><form action='?".$pre_send."' method='post'> ";
    echo "��ǰ��ѯ��   " . $day ." -> " . $plat ." -> " . $project;
    echo '<a style="margin-left:100px">';
//������ҳ����һҳ����һҳ��βҳ��ҳ��ֵ >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    $first=1;
    $prev=$page-1;
    $next=$page+1;
    $last=$pages;
    //�����ҳ����תҳ��ʱ������ǰѡ��������
    if ($page>1) {
        echo "<a href='?page=".$first."&".$pre_send."'>��ҳ</a> ";
        echo "<a href='?page=".$prev."&".$pre_send."'>��һҳ</a> ";
    }
    if ($page<$pages) {
        echo "<a href='?page=".$next."&".$pre_send."'>��һҳ</a> ";
        echo "<a href='?page=".$last."&".$pre_send."'>βҳ</a> ";
    }
    echo "ת��<input type=text name='ys' size='1' value=".$page.">ҳ/$pages";
    if ($pages>1) {
        echo '<input type=submit name="submit" value="��ѯ" style="margin-left:10px">';
    }
    echo "</form>";
    echo "</div>";
?>
