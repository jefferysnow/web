#!/usr/bin/perl -w
# UAT_B79_NEW_WEB log日志入库，使用方法：perl + 脚本 + 文件名 + 行数
# jeffery 2016-08-04
use strict;
use warnings;
my $filename = shift or die "Usage: $0 file numlines\n";
my $numlines = shift ;
my $byte;

open FILE, "<$filename" or die "Couldn't open $filename: $!";
seek FILE,-1, 2; #大文件快速定位
my $count=0;
while (1){
seek FILE,-1,1;
read FILE,$byte,1;
if(ord($byte) eq "10" ){$count++;if($count eq "$numlines"){last}}
seek FILE,-1,1;
if (tell FILE == 0){last}
}
$/=undef;
my $tail = $_ ;
print "$tail\n";
