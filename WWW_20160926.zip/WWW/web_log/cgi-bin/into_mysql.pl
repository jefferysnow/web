#!/usr/bin/perl -w
use warnings; 
use strict;
use DBI;
my $dsn = "DBI:mysql:database=uat_log;host=localhost";
my $mysqluser = 'uatadmin';
my $password = 'ag866.com';
our ($dbh,$sth,@ary);
our($date,$time,$info,@null,$user,$billno,@message,$message,@mess,$ip,$null,$host,$pre);

$dbh = DBI->connect($dsn,$mysqluser,$password);
$dbh->{'mysql_enable_utf8'} = 1;
$dbh->do('set names utf8');

my $sql = " insert into uat_b79_web_20160805(ip,date,time,info,user,billno,message) values(?,?,?,?,?,?,?)";
$sth = $dbh->prepare($sql);
open (DATE,"/logs/catalina.out.2016-08-03.bak");
while (<DATE>) {
  next if ( /^	/ );
  next if ( /Servlet.service/ );
  next if ( /\s\s\s\s/ );
  next if ( /^com/ );
  next if ( /^Caused/ );
  next if ( /^java/ );
  next if ( /^org/ );
  if (/\}/){
    if (/^WTT|EST|WZ/){
      ($pre,@message) = split /\}/;
      ($host,$ip,$date,$time,$info) = split /\s\]\s\[|\]\s\[|\]\s\|\s\[|\[|\]|\s/,$pre ;
    }
    else {
      ($null,$date,$time,$info) = split /\s\]\s\[|\]\s\[|\]\s\|\s\[|\[|\]|\s/,$pre ;
    }
  }
  else {
    ($pre,@message) = split /\|/;
    ($host,$ip) = split /\[|\]/,$pre;
  }
  if (@message) {
    #print "test for ip:$ip \t date:$date \t time:$time \t info:$info \t message:@message" ;
    $sth->execute($ip,$date,$time,$info,$user,$billno,"@message");
  }
}
close (DATE);

$sth->finish;
$dbh->disconnect;
