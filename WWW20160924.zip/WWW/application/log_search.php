<?php
    require_once('../main/logs.php');
    require_once('../config/conn.php');
    
    //�����̳�
    $day       = trim($_POST['day']);
    $plat      = trim($_POST["plat"]);
    $project   = trim($_POST["project"]);
    $begintime = trim($_POST["begintime"]);
    $search    = trim($_POST["search"]);
    $pagesize  = trim($_POST["content"]);
    $search_day = str_replace('-','',$day);
    //$page      = trim($_POST["page"]) or "1" ;

    //��������-->�������
    if ($plat == "b79"&&$project == "web"){
        $tab_name = $plat ."_new_". $project ."_". $search_day ;
    }
    else {
        $tab_name = $plat ."_". $project ."_". $search_day ;
    }
    //��������-->ȥ��������Ŀո�
    trim($search); 
    trim($search_day);

    //$query_all_sql = "select id from $tab_name ";
    //$result_all_date = $db->query($query_all_sql);
    //$result_all_rows = $result_all_date->num_rows;
    //$pagecount = ceil($result_all_rows/$pagesize);
    //$startpage = 1;

    //�ϳ���SQL�Ӿ䣬ȷ��������Ŀ
    $query_rows_sql = "select id from $tab_name ";
    
    if ($begintime != "00:00:00"){
        if ($search != "all"){
            $query_rows_sql .= " where time >= '$begintime' " . " and message like '%$search%' " ;
        }
        else {
            $query_rows_sql .= " where time >= '$begintime' "   ;
        }
    }
    /*
    //��ѯ��������
    $result_search_date=mysqli_query($link, $query_rows_sql);
    $result_search_rows = $result_search_date->num_rows;
    //������ҳ��
    $pagecount = ceil($result_search_rows/$pagesize);
    
    //��ҳ��Ϣ--��ȡ��ʼҳ��
    if($_GET[page]){
        $pageval=$_GET[page];
        $page=($pageval-1)*$pagesize;
    }
    //��ҳ��Ϣ--�������ѯ��ҳ����ڻ������ҳ�룬��ѯҳ��=���ҳ��
    if( $pageval>=$pagecount){
        //echo $int;
        $pageval=$pagecount;
    };
    //��ҳ��Ϣ--����ID
    $startid = $page ;
    $endid   = $page + $pagesize ;
    */
    $startid = 1;$page=1;
    $endid = $pagesize;
    //�ϳɲ�ѯ����SQL
    $query_date_sql = "select id,ip,date,time,info,message from $tab_name ";
    $query_limit = "limit $page,$pagesize ";
    if ($begintime != "00:00:00"){
        if ($search != "all"){
            $query_date_sql .= " where time >= '$begintime' " . " and message like '%$search%' " . $query_limit ;
        }
        else {
            $query_date_sql .= " where time >= '$begintime' " . $query_limit   ;
        }
    }
    else {
        $query_date_sql = $query_date_sql . "where id >= $startid and id < $endid " ;
    }
    
    //print htmlspecialchars($query_search_date);
    $result_search_date = $link->query($query_date_sql);
    for ($i=1;$i<$pagesize;$i++){
        $show_search_date = $result_search_date->fetch_assoc();
        //$id      = trim($show_search_date['id']);
        //$date    = trim($show_search_date['date']);
        $time    = trim($show_search_date['time']);
        $info    = trim($show_search_date['info']);
        $message = trim($show_search_date['message']);
        if (preg_match("/^at/",$message)){
            $date = '';
            $time = '';
            $info = '';
        }
        echo '<tr ><td style="white-space:nowrap;color:grey">' ;
        //echo htmlspecialchars(stripcslashes($id));
        //echo '</td><td style="white-space:nowrap;">| ' ;
        //echo htmlspecialchars(stripcslashes($date));
        //echo '</td><td style="white-space:nowrap;">' ;
        echo htmlspecialchars(stripcslashes($time));
        echo '</td><td style="white-space:nowrap;text-align: right;font-size:0.5px;color:grey">' ;
        echo htmlspecialchars(stripcslashes($info)) .'&nbsp&nbsp';
        echo '</td><td style="word-wrap:break-word;word-break:break-all;font-size:2px">' ;
        echo htmlspecialchars(stripcslashes($message));
        echo "</td></tr>";
    }
    //print '</div><div style="height:25px;line-height: .02em;">�ܹ�:';
    //print $result_all_rows;
    /*
    if($pagecount > $pagesize){
        if($pageval<=1){
            $pageval=1;
        }
    }
    echo "�� $num ��".
    " <a href=$url?page=".($pageval-1).">��һҳ</a> <a href=$url?page=".($pageval+1).">��һҳ</a>";
    */
?>
