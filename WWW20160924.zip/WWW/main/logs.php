<?php
  require('../include/logs_header.php');
?>

<!--����header.phpδ��ɵĲ˵�-->
    <li><A href="./../main/main_page.php">��ҳ</A></li>
    <li><A href="./../main/task.php">�������</A></li>
    <li><A href="./../main/maintain.php">�ճ���ά</A></li>
    <li><A href="./../main/domain.php">��������</A></li>
    <li><A href="./../main/listen.php">��ع���</A></li>
    <li><A class="hover" href="./../main/logs.php">��־��ѯ</A></li>
    <li><A href="./../main/roster.php">�Ű�ı�</A></li>
    <li><A href="./../main/help.php">ʹ��˵��</A></li>
    <div id="lanPos"></div>
  </ul>
</td><!-- �˵��������td -->
<td class="content"  >
  <form action="../application/log_search.php" method="POST" style="line-height: .02em;width:100%">
    <div style="width: 100%;height: 10%;text-indent: 10px; line-height: 25px;">
      <div>
      ƽ̨:
        <select name="plat" >
          <option value="b79"> B79 </option>
          <option value="p02"> P02 </option>
        </select>
      &nbsp&nbsp��Ŀ:
        <select name="project">  <option value="web"> WEB </option>
          <option value="web_ws"> WEB_WS
          <option value="vipweb" > VIP_WEB
          <option value="gi" > GI 
          <option value="office"> OFFICE
          <option value="office_ws"> OFFICE_WS
          <option value="mobile"> MOBILE	
        </select>
      &nbsp&nbsp�ؼ���:
        <input  type="text" size='15' name="search" value="all" onfocus="this.value=''" onblur="if(this.value==''){this.value='all'}" />
        <input type="SUBMIT" value="��ѯ" style="text-align: right"/>
    &nbsp&nbsp&nbsp&nbsp
        <input type="button" value="��ѯ����" name="LostQuery" onclick="LostQuery">
        <input type="submit" value="ʵʱ��ʾ">
      </div>
      <div style="position:relative;">
        <span style="overflow:hidden;">
        ����:
          <input class="inputDate" id="inputDate" name="day" style="width: 72px"/>
          <!--���ù�ѡ�Զ��ر����ڿؼ�
          <label id="closeOnSelect"><input type="checkbox" /> Close on selection</label>-->
        ʱ��:
          <!--δ���������select���⣬ʱ�们�������
          <select name="begintime" id="valueA" class="SelectList"
            onclick="document.getElementById('sbtlInp222').value=this.options[this.selectedIndex].text">
          </select> -->
          <input name="begintime" type="text" class="SelectList" value="00:00:00" style="width:65px;text-align: center">
        &nbspÿҳ<select name="content" >
          <option value="100" >100</option>
          <option value="300" >300</option>
          <option value="500" >500</option>
          <option value="1000" >1000</option></select>��&nbsp&nbsp&nbsp&nbsp
        </span>
      </div>
        <!--ѭ������ʱ��ѡ��-->
        <script type="text/javascript"> 
          for (var i=0;i<24;i++) {
            if (i<10) {
              i="0"+i
            }
            for (var j=0;j<60;j=parseInt(j, 10)+10) {
              if (j<10) {
                j="0"+j
              }
              var time=i+":"+j+":00";
              var obj = document.getElementById("valueA");
              obj.add(new Option(time,time));
            }
          }
        </script>
      <!--��־����
      <div>
        <span style="width:100px;position:absolute;left:6%;">
            id
        </span>
        <span style="width:100px;position:absolute;left:9%;">
            ʱ��
        </span>
        <span style="width:100px;position:absolute;left:15%;">
            INFO
        </span>
        <span style="width:100px;position:absolute;left:26%;">
            MESSAGE
        </span>
      </div>
      -->
    </div>
  <!--�˵�������-->
  
  <!--����·�С��10��0-->
  <script language="JavaScript"> 
    var now = new Date();
    m=(now.getMonth()+1);
    if (m<10) {
      m = "0" + m;
    }
    inputDate.value=now.getFullYear() + "-"+ m +"-"+now.getDate();  
  </script></div>
  

  <!--�淶��־��ʾ-->
  <div class="autoScroll" ><table><tbody style="font-size:1px;">



