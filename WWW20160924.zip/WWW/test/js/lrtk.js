/* ����������400Ӱ�� www.400ys.com */
  $(document).ready(function(){

    function checktime(olddel){

      var now = new Date();

        var nowdel = now.getDay() + "|" + now.getMonth() + "|" + now.getDate() + "|" + now.getHours() + "|" + now.getMinutes() + "|" + now.getSeconds();

        if ( olddel != nowdel ) {

          var oldsplit = olddel.split("|");
          var nowsplit = nowdel.split("|");

          if ( oldsplit[5] != nowsplit[5] ) {

            clock_slide('#sec',nowsplit[5],11);
            if ( oldsplit[4] != nowsplit[4] ) {

              clock_slide('#min',nowsplit[4],11);
              if ( oldsplit[3] != nowsplit[3] ) {

                clock_slide('#hour',nowsplit[3],28);
                if ( oldsplit[2] != nowsplit[2] ) {

                  clock_slide('#day',nowsplit[0],100);
                  clock_slide('#date',(nowsplit[2]-1),22);

                  if ( oldsplit[1] != nowsplit[1] ) {
                    clock_slide('#month',nowsplit[1],57);

                  };
                };
              };
            };
          };
        };

        function clock_slide(which,howmuch,multiple){
          $(which).stop().animate({marginLeft: ((howmuch*multiple)-700)+'px'}, 250, 'linear');
        };

        setTimeout(function(){checktime(nowdel);}, 250);


    };

      checktime("0|0|0|0|0|0");

  });
