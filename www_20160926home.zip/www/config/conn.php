<?php
$host="10.252.252.244";    
$db_user="sa";    
$db_pass="ag866.com";
$db_name="web_log";
$timezone="Asia/Shanghai";
$link=@mysqli_connect($host,$db_user,$db_pass) ;
@mysqli_select_db($link, $db_name);
@mysqli_query($link, "SET names gb2312");
?>