<!-- page footer -->
    <table width="100%" bgcolor="black" cellpadding="12" border="0" >
    <tr>
        <td>
            <p class="foot">&copy; sa@ag866.com</p>
        </td>
    </tr>
    </table>
</body>
</html>