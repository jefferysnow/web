<?php
require_once('conn.php'); //�������ݿ� 
 
$user = array('demo1','demo2','demo3','demo3','demo4'); 
$page = intval($_GET['page']);  //��ȡ�����ҳ�� 
$start = $page*15; 
$query=mysqli_query($link, "select * from say order by id desc limit $start,15"); 
/* while ($row=mysqli_fetch_array($query)) { 
    $arr[] = array( 
        'content'=>$row['content'], 
        'author'=>$user[$row['userid']], 
        'date'=>date('m-d H:i',$row['addtime']) 
    ); 
}  */
if($query){
    while ($row=mysqli_fetch_array($query)) { 
        $arr[] = array( 
            'content'=>$row['content'], 
            'author'=>$user[$row['userid']], 
            'date'=>date('m-d H:i',$row['addtime']) 
        ); 
    } 
}
if(!empty($arr)){
    echo json_encode($arr);  //ת��Ϊjson������� 
}
//echo json_encode($arr);  //ת��Ϊjson������� 
?>