<?php
  require('../include/logs_header.php');
  //�ύ��ѯ����ѡ��ѡ�
  $select_plat     = isset($_REQUEST['plat'])?$_REQUEST['plat']:'';
  $select_project  = isset($_REQUEST['project'])?$_REQUEST['project']:'';
  $select_content  = isset($_REQUEST['content'])?$_REQUEST['content']:'';
  $input_begintime = isset($_REQUEST['begintime'])?$_REQUEST['begintime']:'00:00:00';
  if (empty($begintime)){
    $input_begintime = '00:00:00';
  }
?>

<!--����header.phpδ��ɵĲ˵�-->
    <li><A href="./../main/main_page.php">��ҳ</A></li>
    <li><A href="./../main/task.php">�������</A></li>
    <li><A href="./../main/maintain.php">�ճ���ά</A></li>
    <li><A href="./../main/domain.php">��������</A></li>
    <li><A href="./../main/listen.php">��ع���</A></li>
    <li><A class="hover" href="./../main/logs.php">��־��ѯ</A></li>
    <li><A href="./../main/roster.php">�Ű�ı�</A></li>
    <li><A href="./../main/help.php">ʹ��˵��</A></li>
    <div id="lanPos"></div>
  </ul>
</td><!-- ���˵��������td -->
<td class="content"  > <!-- ҳ�������td -->
  <form action="../application/log_search.php" method="POST" style="line-height: .02em;width:100%">
    <div style="width: 100%;height: 10%;text-indent: 10px; line-height: 25px;">
      <div>
      ƽ̨:
        <select name="plat" >
          <option value="b79" <?php echo $select_plat == 'b79' ? 'selected' : ''?> > B79 </option>
          <option value="p02" <?php echo $select_plat == 'p02' ? 'selected' : ''?> > P02 </option>
        </select>
      &nbsp&nbsp��Ŀ:
        <select name="project" id="project">
          <option value="web"    <?php echo $select_project == 'web' ? 'selected' : ''?> > WEB
          <option value="web_ws" <?php echo $select_project == 'web_ws' ? 'selected' : ''?> > WEB_WS
          <option value="vipweb" <?php echo $select_project == 'vipweb' ? 'selected' : ''?> > VIP_WEB
          <option value="gi"     <?php echo $select_project == 'gi' ? 'selected' : ''?> > GI 
          <option value="office" <?php echo $select_project == 'office' ? 'selected' : ''?> > OFFICE
          <option value="mobile" <?php echo $select_project == 'mobile' ? 'selected' : ''?> > MOBILE	
          <option value="office_ws" <?php echo $select_project == 'office_ws' ? 'selected' : ''?> > OFFICE_WS
        </select>
      &nbsp&nbsp�ؼ���:
        <input  type="text" size='15' name="search" value="all" onfocus="this.value=''" onblur="if(this.value==''){this.value='all'}" />
        <input type="submit" name="query" value="��ѯ" style="text-align: right"/>
      &nbsp&nbsp&nbsp&nbsp
        <input type="submit" name="query_lost"  value="��ѯ����" style="text-align: right"/>
        <input type="submit" name="query_ontime"  value="ʵʱ��ʾ" style="text-align: right"/>
      </div>
      <div style="position:relative;">
        <span style="overflow:hidden;">
        ����:
          <input class="inputDate" id="inputDate" name="day" style="width: 72px"/>
          <!--���ù�ѡ�Զ��ر����ڿؼ�
          <label id="closeOnSelect"><input type="checkbox" /> Close on selection</label>-->
        ʱ��:
          <input name="begintime" type="text" value="<?php echo $input_begintime ;?>" style="width:65px;text-align: center" />
        &nbspÿҳ
          <select name="content" >
            <option value="1000" <?php echo $select_content == '1000' ? 'selected' : ''?> >1000</option>
            <option value="2000" <?php echo $select_content == '2000' ? 'selected' : ''?> >2000</option>
            <option value="3000" <?php echo $select_content == '3000' ? 'selected' : ''?> >3000</option>
            <option value="5000" <?php echo $select_content == '5000' ? 'selected' : ''?> >5000</option>
          </select>��&nbsp&nbsp&nbsp&nbsp
          <a href="../main/logs.php"><input type="button" value="����"></a>
        </span>
      </div>
          <!--ʱ�������---������
          <select name="begintime" id="valueA" class="SelectList"
            onclick="document.getElementById('sbtlInp222').value=this.options[this.selectedIndex].text">
          </select> 
          <--ѭ������ʱ��ѡ��
          <script type="text/javascript"> 
          for (var i=0;i<24;i++) {
            if (i<10) {
              i="0"+i
            }
            for (var j=0;j<60;j=parseInt(j, 10)+10) {
              if (j<10) {
                j="0"+j
              }
              var time=i+":"+j+":00";
              var obj = document.getElementById("valueA");
              obj.add(new Option(time,time));
            }
          }
        </script>-->
    </div><!--��־�˵�������-->

  <!--�Զ���ȡ�������ڣ�����ѡ������-->
  <script language="JavaScript"> 
    var now = new Date();
    m=(now.getMonth()+1);
    if (m<10) {
      m = "0" + m;
    }
    var today=now.getFullYear() + "-"+ m +"-"+now.getDate();
    inputDate.value= <?php
      if (isset($_REQUEST['day'])) {
        $input_day = $_REQUEST['day'];
        echo "\"$input_day\"" ;
      }
      else {
        echo 'today';
      }  ?> ;
  </script></div>


  <!--��־��ʾdiv,������ʾ��ʽ-->
  <div class="autoScroll" ><table><tbody style="font-size:1px;">
