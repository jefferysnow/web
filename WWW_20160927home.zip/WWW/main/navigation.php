<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="zh"
    lang="zh"
    dir="ltr">

<head>
    <link rel="icon" href="./favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
    <title>phpMyAdmin</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <base target="frame_content" />
    <link rel="stylesheet" type="text/css"
        href="phpmyadmin.css.php?token=e667c5e5465493ce3d75d9d50b978a74&amp;js_frame=left&amp;nocache=4239093868" />
    <script src="./js/jquery/jquery-1.6.2+fix-9521.js?ts=1374964490" type="text/javascript"></script>
<script src="./js/jquery/jquery-ui-1.8.16.custom.js?ts=1374964490" type="text/javascript"></script>
<script src="./js/jquery/jquery.qtip-1.0.0-rc3.js?ts=1374964490" type="text/javascript"></script>
<script src="./js/navigation.js?ts=1374964490" type="text/javascript"></script>
<script src="./js/functions.js?ts=1374964490" type="text/javascript"></script>
<script src="./js/messages.php?ts=1374964490" type="text/javascript"></script>
<script src="./js/get_image.js.php?theme=pmahomme" type="text/javascript"></script>
    <script type="text/javascript">
    // <![CDATA[
    // INIT PMA_setFrameSize
    var onloadCnt = 0;
    var onLoadHandler = window.onload;
    var resizeHandler = window.onresize;
    window.document.onresize  = resizeHandler;
    window.onload = function() {
        if (onloadCnt == 0) {
            if (typeof(onLoadHandler) == "function") {
                onLoadHandler();
            }
            if (typeof(PMA_setFrameSize) != 'undefined' && typeof(PMA_setFrameSize) == 'function') {
                PMA_setFrameSize();
            }
            onloadCnt++;
        }
    };
    window.onresize = function() {
        if (typeof(resizeHandler) == "function") {
            resizeHandler();
        }
        if (typeof(PMA_saveFrameSize) != 'undefined' && typeof(PMA_saveFrameSize) == 'function') {
            PMA_saveFrameSize();
        }
    };
    // ]]>
    </script>
        <!--[if IE 6]>
    <style type="text/css">
    /* <![CDATA[ */
    html {
        overflow-y: scroll;
    }
    /* ]]> */
    </style>
    <![endif]-->
</head>

<body id="body_leftFrame">
<div id="pmalogo">
<a href="main.php?token=e667c5e5465493ce3d75d9d50b978a74" target="frame_content"><img src="./themes/pmahomme/img/logo_left.png" alt="phpMyAdmin" id="imgpmalogo" /></a>
</div>
<div id="leftframelinks">
<a href="main.php?token=e667c5e5465493ce3d75d9d50b978a74" title="主页"><img src="themes/dot.gif" title="主页" alt="主页" class="icon ic_b_home" /></a>
<a href="index.php?token=e667c5e5465493ce3d75d9d50b978a74&amp;old_usr=root" target="_parent" title="退出" ><img src="themes/dot.gif" title="退出" alt="退出" class="icon ic_s_loggoff" /></a>
<a href="querywindow.php?token=e667c5e5465493ce3d75d9d50b978a74&amp;no_js=true" title="查询窗口" onclick="if (window.parent.open_querywindow()) return false;"><img src="themes/dot.gif" title="查询窗口" alt="查询窗口" class="icon ic_b_selboard" /></a>
    <a href="Documentation.html" target="documentation" title="phpMyAdmin 文档" ><img src="themes/dot.gif" title="phpMyAdmin 文档" alt="phpMyAdmin 文档" class="icon ic_b_docs" /></a><a href="./url.php?url=http%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F5.5%2Fen%2Findex.html&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="mysql_doc"><img src="themes/dot.gif" title="文档" alt="文档" class="icon ic_b_sqlhelp" /></a>
<a href="navigation.php??uniqid=57e9e3f7b3f12&amp;token=e667c5e5465493ce3d75d9d50b978a74" title="刷新导航框架" target="frame_navigation"><img src="themes/dot.gif" title="刷新导航框架" alt="刷新导航框架" class="icon ic_s_reload" /></a></div>
<div id="recentTableList">
<form method="post" action="index.php" target="_parent">
<input type="hidden" name="token" value="e667c5e5465493ce3d75d9d50b978a74" />
<input type="hidden" name="goto" id="LeftDefaultTabTable" value="tbl_structure.php" /><select name="selected_recent_table" id="recentTable"><option value="">(最近使用的表) ...</option><option value="">没有最近使用的表</option></select><noscript>
<input type="submit" name="Go" value="执行" />
</noscript>
</form>
</div>
<ul id="databaseList" xml:lang="en" dir="ltr">
<li><a href="index.php?db=information_schema&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="_parent">information_schema</a></li>
<li><a href="index.php?db=mysql&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="_parent">mysql</a></li>
<li><a href="index.php?db=performance_schema&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="_parent">performance_schema</a></li>
<li><a href="index.php?db=sa_work&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="_parent">sa_work</a></li>
<li><a href="index.php?db=test&amp;token=e667c5e5465493ce3d75d9d50b978a74" target="_parent">test</a></li>
</ul>

<div id="left_tableList">
</div>
</body></html>