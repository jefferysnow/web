<meta http-equiv="Content-Type" content="text/html charset=gb2312" xml:lang="en" lang="en">
<title>SA workpage</title>
<script src="../css/position.css" type="text/css"></script>
<link href="../css/basic.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script src="../js/jquery.min.js"></script>
<script src="../js/index.js"></script>
<script src="../js/clock.js" type="text/javascript"></script>

<!--body����-->
<body onload="startTime()" text="#000000" style="height: 96%">

<!--��ҳ����-->
<table width="100%"  cellspacing="0" border="0" style="background-color: teal" >
    <tr >
      <td  width="35%">
        <img src="./../image/tcbc_teal.png" align=right >
      </td>
      <td width="35%" >
        <h1 >SA WorkPage</h1>
      </td>
      <td>
        <!-- ���Ͻǵ�ʱ��-->
        <span id="clock" class="clock"></span>
      </td>
    </tr>
</table>
<div> <a class="rollinfo">�����Ǵ��졢�澯�Ĺ�����Ϣ����</a></div>

<table width=100% style="height: 90%" cellpadding="5px" > <!-- ��������������-->
    <tr>
    <!-- ���˵���ʼtd -->
    <td class="menu"> 
    <ul >