#!/usr/bin/perl -w
# created by jeffery  2016-08-02
use strict;
use warnings ;
use CGI ;use DBI; use POSIX qw(strftime);

our ($db_name,$host,$mysqluser,$password,$content,$req,$plat,$project,$time,$start_line,$end_line,$page,$search,$id);

#子程序 ----> 查询结果返回界面的菜单
sub paging_show {
#处理分面信息。
our $rows ;
our $j=1 ; #页面初始值
our $w=$rows ;
while ($w>0) {
  $w=$w-$content;
  $j++;
  }
my $all_j = ($j-1);
our $prev=$page-1; #上一页
our $next=$page+1; #下一页
our $last=$all_j;  #尾页
if ( $next >= $j ) { $next = $all_j } ;
if ( $prev >= $j ) { $prev = $all_j } ;
if ( $page >= $j ) { $page = $all_j } ;
#数据查询页面菜单
print $req->a(qq(<table border='0'  width="98%" style="word-break:break-all; word-wrap:break-word;" cellspacing="1" cellpadding="1px" >
                 <body top=1;style="width:95%; height:100%; margin-left:0px; margin-top:0px;">));
print $req->a(qq(<a href="../index.html">返回首页</a> | 
                 <a href="?search=$search&page=$prev&time=$time&plat=$plat&project=$project&content=$content">上页</a> | 
                 <a href="?search=$search&page=$next&time=$time&plat=$plat&project=$project&content=$content">下页</a> | 
                 <a href="?search=$search&page=$last&time=$time&plat=$plat&project=$project&content=$content">尾页</a> ));
#print $req->a(qq(<tr><form action="./post.cgi?search=$search&page=$page&time=$time&plat=$plat&project=$project" method="GET">
print $req->a(qq(<tr><form action="./post.cgi" method="GET">
                 <a> &nbsp 跳转至：
                 <input size="1" type="text" name="page" value="$page" onfocus="this.value=''" onblur="if(this.value==''){this.value='$page'}"/> </a> 
                 <input type="hidden" name="search" value="$search"/><input type="hidden" name="time" value="$time"/>
                 <input type="hidden" name="plat" value="$plat"/><input type="hidden" name="project" value="$project"/><input type="hidden" name="content" value="$content"/>
                 <font size="1">\(共:$all_j\)</font>
                 <a> &nbsp 关键字(用户名): 
                 <input  type="text" size='10' name="user"/>
                 <input type="hidden" name="page" value="$page"/><input type="hidden" name="time" value="$time"/><input type="hidden" name="search" value="$search"/>
                 <input type="hidden" name="plat" value="$plat"/><input type="hidden" name="project" value="$project"/><input type="hidden" name="content" value="$content"/>
                 <input type="SUBMIT" values="GO"/> </form><tr>  ));
#数据查询结果标题
print $req->a(qq(<tr bgcolor=#6699FF ;border-bottom:1px #ddd solid>
                 <th  width=4% nowrap>rowid</th>
                 <th width=6% nowrap>date</th>
                 <th width=5% nowrap>time</th>
                 <th width=3% nowrap>info</th>
                 <th nowrap>message</th>
                 </tr>));
print $req->a("</body>");
                 #<th width=8% nowrap>user</th>
#print $req->a("test for page:$page,rows:$rows,all_page:$all_j ");
};

#子程序 ---> 数据库连接
sub connect_mysql {
our $dbh = DBI->connect("DBI:mysql:database=$db_name;host=$host",$mysqluser,$password,
  {
  PrintError => 1,#出错时warn()
  RaiseError => 0,#错误时并不结束执行
  AutoCommit => 1,#立即提交
  }
 );
$dbh -> do ("SET NAMES UTF8"); #设置中文显示utf8。
};

#子程序 ----> 数据查询
sub query_date {
our ($sql,$dbh) ;
#  print $req->a("test for sql:$sql ");
  our $sth_all=$dbh->prepare($sql);
      $sth_all->execute || print $req->p("&nbsp&nbsp 查询数据未建立或已经删除(数据保留一星期)");
      while ( my @row=$sth_all->fetchrow_array) {
          our ($search,$prev,$time,$plat,$project,$content);
          print $req->p(qq(<font size="8"><tr>
                           <td style="border-bottom:1px dashed #cccccc;" align='middle' valign ='top' cellspacing=10>
                              <a href="?&time=$time&plat=$plat&project=$project&content=$content&id=$row[0]" title="服务器ip:$row[6]">$row[0]</a></td>
                           <td style="border-bottom:1px dashed #cccccc;" align='middle' valign ='top'>$row[1]</td>
                           <td style="border-bottom:1px dashed #cccccc;" align='middle' valign ='top'>$row[2]</td>
                      ));
          if ( $row[3] eq 'ERROR' ){print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' bgcolor=\"#FFD700\" valign ='top'>$row[3]</td>";}
            else {print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' valign ='top'>$row[3]</td>";}
          print "<td style=\"border-bottom:1px dashed #cccccc;\" align='left' valign ='top'> $row[5] </td></tr></font>";
      }
      print "</table>";
}

#            if ( $row[3] eq 'ERROR' ){print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' bgcolor=\"#FFD700\" valign ='top'>$row[3]</td>";}
#            else {print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' valign ='top'>$row[3]</td>";}
#            if ( $row[4] eq '_' ){print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' valign ='top'></td>";}
#            else {print "<td style=\"border-bottom:1px dashed #cccccc;\" align='middle' valign ='top'>[$row[4]]</td>";}
#子程序 ----> 返回顶部
sub back_top {
print <<HTML;
 <head>
 <style type="text/css">
 *{ margin:0; padding:0;}
 .nav-wrapper-fixed{ position:fixed; top:220; width:100%;}
 .nav-wrapper-fixed .nav{width:960px; margin:0 auto;}
 .nav-wrapper-fixed .nav li{ float:left; width:100px; margin-right:5px; background:#CCC; text-align:center; height:24px; line-height:24px; list-style:none;}
 .nav-wrapper{ margin-top:100px; width:100%;}
 .nav-wrapper .nav{width:960px; margin:0 auto;}
 .nav-wrapper .nav li{ float:left; width:100px; margin-right:5px; background:#CCC; text-align:center; height:24px; line-height:24px; list-style:none;}
 </style>
 <script type="text/javascript">
     window.onload = function () {
         var nav = document.getElementById('nav');
         var navFixed = document.getElementById('navFixed');
         window.onscroll = function () {
             var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
             document.title = scrollTop
             if (scrollTop > nav.offsetTop) {
                 navFixed.style.display = 'block';
             } else if (scrollTop < nav.offsetTop) {
                 navFixed.style.display = 'none';
             }
         }
     };
 </script>
 </head>
 <body style="height:2000px;">
 <div class="nav-wrapper">
     <div class="nav" id="nav">
         <ul>
             <li>菜单一</li>
             <a href=\"#top\" target=\"_self\">返回顶部</a>
         </ul>
     </div>
 </div>
 <div class="nav-wrapper-fixed" id="navFixed" style="display:none;">
     <div class="nav" id="nav">
         <ul>
             <li>菜单一</li>
             <a href=\"#top\" target=\"_self\">返回顶部</a>
         </ul>
     </div>
 </div>
 </body>
HTML
};
1;
